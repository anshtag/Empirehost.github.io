# aternos-template
The template repository for the Aternos course on Learning Lab.
